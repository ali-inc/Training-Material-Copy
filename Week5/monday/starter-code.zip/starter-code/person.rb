class Person

    def name
        # create a name variable
    end

    def age
        # create age variable here

    end

    def children
        # create children array here

    end

    def address

        # create address hash here

    end

    def password

        # do not change these variables
        favourite_things = ["motorbike" , "cat" , "travel"]
        memorable_stuff = {
          birth_year: 1983,
          mothers_name: "Eve",
          birth_town: "Richmond"
        }

    end

end
