$(document).ready(function() {

  var newFacts = [
  	"Big Ben is the name of the bell - the building is called Elizabeth Tower", 
  	"France was still executing people by guillotine when the first Star Wars movie came out.", 
  	"What is called a “French kiss” in the English speaking world is known as an “English kiss” in France.", 
  	"At any one time, about 0.7% of the world’s population is drunk."
  ];

});
