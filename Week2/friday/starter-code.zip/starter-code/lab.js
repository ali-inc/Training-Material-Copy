// create a variable called first_name that contains a string

// create an array that contains three names
// use your first_name variable for the third name

// create a variable called number_of_names that contains the number of people in your names array

// create a variable called age and put an appropriate data type in it

// create a variable called younger that contains a third of this age

// create a null variable called empty

// create a variable called phone_number and store this number 07888777396
// ( think about what type of data would be best for this )

// create a variable called friend
// extract the second value from your names_array and put it in friend

// create a variable called quote that contains the following sentence
// I'm not a number, I'm fairly sure I'm a String


// create a variable called sentence_length that contains the length of the sentence


// BONUS
// Research how to create a JSON object called person
// Use the person object tests to add the correct data



