Given("have a before hook in place") do
  @users.each do |user|
    puts user
  end
end

Then("I can validate the information in the before hook") do
end

Given("I use a tag") do
end

Then("only this test will run") do
end
