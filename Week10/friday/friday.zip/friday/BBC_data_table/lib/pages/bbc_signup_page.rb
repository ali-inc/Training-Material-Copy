class BBCSignUpPage
  include Capybara::DSL

end
